# Links for other skills

Author: TABARC-Code

The other half of each link declared in `SKILL.md`. Paste the block into the named skill's own `SKILL.md` (or its links section) so both ends say the same thing. I haven't edited any of those skills; a few of them I could only see as synced copies, and overwriting a current version from a stale copy is how regressions happen.

Each block follows the same rule as the main skill: a link only exists if it changes what the skill does.

## humanizer

```
## Links
- syntax-friction-engine (out): when the problem is sentence shape rather than vocabulary
  (dropped "that", noun stacks, a verb that turns up late, sentences over 25 words), hand the
  text over. Take back the revised text, then run the lexical pass here.
- syntax-friction-engine (in): it calls this skill after its readability and feature passes
  to catch vocabulary habits. Expect text that is already short-sentenced; don't re-pad it.
- Evidence worth carrying both ways: false flags and accepted rewrites from this skill's runs
  belong in syntax-friction-engine's feedback ledger; its fix table is worth reading here.
```

## overwatch-prose-audit

```
## Links
- syntax-friction-engine (out): route findings about sentence shape (reduced relatives,
  stacked nouns, late verbs, over-long sentences or paragraphs) to it, not to a vocabulary
  fixer. Ask for its before-and-after report, including the meaning-guard result.
- syntax-friction-engine (in): it sends lexical findings back here or to humanizer.
- Do not treat its counts as a verdict on authorship. It says so itself.
```

## technical-clarity-engine

```
## Links
- syntax-friction-engine (out, on request): when text must stay in controlled vocabulary but
  its sentences are still long or dense, hand it over for the readability pass.
- syntax-friction-engine (in, on request): when a user wants restricted vocabulary on top of
  easier syntax, it hands the text here. Its BLUNT intensity already prefers ordinary words,
  so expect little conflict.
```

## em-dash-calibration

```
## Links
- Called by syntax-friction-engine (FULL and BLUNT): that skill unpacks dash-delimited lists
  into sentences, which lowers dash density. Run the final dash check on its output.
```

## professional-technical-writing

```
## Links
- syntax-friction-engine (out): document structure and layout are decided here; once a
  manual or report is laid out, hand the prose to it for sentence-level repair.
- syntax-friction-engine (in): it leaves structure, headings and layout alone and will send
  structure problems back here.
```

## Notes on use

- If a skill isn't installed where you work, the block does no harm; it simply won't be read.
- If a neighbour's maintainer (you, usually) disagrees with a block, change the block, then change the matching line in `SKILL.md` so the two ends still agree. That is the whole contract.
