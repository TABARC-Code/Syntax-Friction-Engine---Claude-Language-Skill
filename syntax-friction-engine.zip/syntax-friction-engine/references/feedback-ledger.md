# Feedback ledger

One line per event. Newest at the bottom. Format:

`date | kind | what | action taken`

Kinds: `reject` (user or you judged a flag or fix wrong), `accept` (fix kept), `miss` (a problem the scorer didn't flag), `regress` (a change made things worse).

Rules of thumb. Same `reject` twice: add to `suppress` in lexicon.json. Same `accept` shape twice: consider it for the fix table in SKILL.md. Any `miss`: add a fixture first, then fix. Any `regress`: revert and note why.

---

2026-10-31 | miss | "the papercut people feel day-to-day" not flagged (parser reads 'people feel' as a main clause) | fixture `papercut` added as known_miss
2026-10-31 | miss | "the bug users hit most often" not flagged ('bug users' parsed as a compound) | fixture `bug-users-hit` added as known_miss
2026-10-31 | miss | very long sentences lose the subject-verb link in the parser | fixture `late-verb-parser-fail` added as known_miss
2026-10-31 | reject | "sub-skill" counted as a three-noun stack (hyphen prefix) | PREFIXES rule in scorer, fixture neg-hyphen-prefix
2026-10-31 | reject | "(the framework wants to...)" flagged inside a quotation (mention, not use) | quoted spans skipped, fixture neg-quoted-mention
2026-10-31 | reject | late_verb fired across a colon (two clauses) | colon/semicolon/dash boundary rule, fixture neg-colon-boundary
2026-10-31 | reject | "a lab chooses" flagged (organisations choose) | organisation nouns added to animate_nouns, fixture neg-org-subject
2026-10-31 | reject | "Stacking nouns" flagged as denominal (old verb in the list) | denominal list cut to novel conversions, fixture neg-old-verb
2026-10-31 | reject | "Olmo Think" read as animate verb "think" (model name) | capitalised mid-sentence verbs skipped, fixture neg-model-name
2026-10-31 | reject | relative clause detected across a semicolon (parse artefact) | skip when ; or : sits between head and verb, fixture neg-semicolon-relcl
2026-10-31 | reject | "every time a generated word reaches" flagged as reduced relative (adverbial; "that" optional) | ADVERBIAL_HEADS list, fixture neg-every-time
2026-10-31 | accept | late verb after a long subject fixed by moving the condition into an "if" clause or putting the verb first (seen in 3 texts) | added to fix table
2026-10-31 | accept | "payment gateway integration" -> "the integration with the payment gateway" (seen twice) | covered by the noun-stack row
2026-10-31 | reject | "outcome will tell us", "Query Monitor will tell you", "data suggests", "briefing argues" flagged (idiom) | already low confidence; left in place
2026-10-31 | note | bold label "Dry-run mode" in a README counted as a noun stack | open: headings and labels are not running prose; consider skipping short bolded labels
2026-10-31 | reject | "After six attempts the client gives up" flagged as reduced relative (fronted phrase, new clause) | skip when the head is the object of a sentence-initial preposition, fixture neg-fronted-pp
2026-10-31 | reject | meaning guard reported "nightly" and "2.3 million" as lost although both were present (NER wobble) | entities now checked by string containment in the revised text
2026-10-31 | note | parser reads "how the EU AI Act affects startups" as a reduced relative | not fixable by rule; left as a known weakness
2026-10-31 | note | "Computer use" (a feature name) counted as a noun stack | open: proper feature names are not caught; user can add to suppress.phrases
2026-10-31 | miss | blind hand-counting found about five times as many constructions in skill-edited text as the scorer did (45 vs 9) | root cause: the loop optimised the scorer; parser misses bare relatives filed as ccomp ("a timeout the client never saw resolved"); added hand-read step to REPAIR
2026-10-31 | regress | blind judges rated feature-only edits no easier than the originals (3.16 vs 3.16), while a plain "short sentences, plain words" revision scored 4.74 | root cause: "minimum effective edit" left long sentences alone; REPAIR now starts with a readability pass
2026-10-31 | note | tried a pattern route for bare relatives the parser files as ccomp; it never fired on real misses (parser errors too deep) | reverted; two fixtures kept as known misses
2026-10-31 | accept | splitting a long sentence into "X. Y." with an "If ... then ..." clause kept the meaning guard passing in every case (3 runs) | in the fix table
2026-10-31 | note | v1.2 final blind test: ease 4.23 vs plain-revision 4.68 (v1.1 3.16, original 2.68); hand-counted constructions per 100 words 0.73 vs 1.38 (v0) and 1.90 (original); meaning-change complaints 2 vs 5 | skill does not beat the plain prompt on ease; claim nothing stronger
2026-10-31 | reject | the 6x target: scorer-only counts reached 4x to 26x depending on set, independent hand-counts only 1.9x (vs v0) and 2.5x (vs original) | scorer figures are inflated because the loop optimises them; report the hand-count
2026-10-31 | reject | numbered list in K1 counted as one 19-sentence paragraph | each list item is now its own paragraph
2026-10-31 | note | tried en_core_web_lg as the parser: fixed 2 known misses (long-sentence late verb, paired-dash aside) but broke 2 passing fixtures (late-verb, neg-quoted-mention); 26/28 vs 28/28 | not adopted; SFE_MODEL env var added for anyone who wants to try it
2026-10-31 | accept | BLUNT intensity (10-12 word sentences, 3-sentence paragraphs, lists unpacked) beat both the plain prompt (10/2/2) and FULL (11/2/1) on blind ease, 14 fresh passages | BLUNT is the default for model-written text
2026-10-31 | reject | plain prompt added content in 4 of 14 passages (invented ordinals, a count, a softened condition); BLUNT had 2 smaller complaints | "add nothing" rule and condition-keeping added to the keep list
2026-10-31 | note | repeat runs on the dense passages: scorer hits 1 and 3 (BLUNT), 1 and 4 (FULL), 20 and 21 (plain prompt); the skill arms are noisier than the baseline | report ranges, not single runs
2026-10-31 | note | scorer vs hand count agreed on original and plain-prompt text (39 vs 37, 28 vs 28) but not on skill output (2 vs 9, 2 vs 8) | the scorer is blind to some of what the skill leaves; hand-read stays
2026-10-31 | accept | BLUNT intensity (10-12 word sentences, 3-sentence paragraphs, lists unpacked) beat both the plain prompt (10/2/2) and FULL (11/2/1) on blind ease, 14 fresh passages | BLUNT is the default for model-written text
2026-10-31 | reject | plain prompt added content in 4 of 14 passages (invented ordinals, a count, a softened condition); BLUNT had 2 smaller complaints | "add nothing" rule and condition-keeping added to the keep list
2026-10-31 | note | repeat runs on the dense passages: scorer hits 1 and 3 (BLUNT), 1 and 4 (FULL), 20 and 21 (plain prompt); the skill arms are noisier than the baseline | report ranges, not single runs
2026-10-31 | note | scorer vs hand count agreed on original and plain-prompt text (39 vs 37, 28 vs 28) but not on skill output (2 vs 9, 2 vs 8) | the scorer is blind to some of what the skill leaves; hand-read stays
2026-10-31 | reject | kebab-case skill and package names (overwatch-prose-audit, em-dash-calibration) counted as three-noun stacks, three times in one README | kebab-case names with two or more hyphens are masked before parsing; fixture neg-kebab-names
2026-10-31 | accept | README and description run through the counter and the humanizer scan: friction per 100 words fell from 1.42 to 0.22 and from 1.26 to 0.21, with no figure lost | remaining hits are false flags (names, a participle, two parser artefacts)
2026-10-31 | note | humanizer tells that survived the first draft of the docs: bold-labelled bullet lists, bold on best table values, a first/second/third/fourth walk, "X, not Y" contrasts used for rhythm, a "main lesson" puff | edited out; worth adding to the DRAFT brief if they recur
