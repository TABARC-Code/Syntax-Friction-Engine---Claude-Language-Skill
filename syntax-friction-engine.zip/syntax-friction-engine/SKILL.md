---
name: syntax-friction-engine
description: Score and fix the sentence shapes that make AI-written technical prose hard to read and obviously machine-made, such as a dropped "that", stacks of nouns, a verb that turns up a line late, subjects like "the framework wants", nouns used as verbs, and over-long sentences. Use whenever the user says text sounds AI-written, dense, clipped, or hard to follow, or asks to make documentation, READMEs, reports, explanations, emails, release notes, postmortems or skill files read more plainly, or asks you to draft technical prose that must read like a person wrote it, even if they never mention syntax. Not for fiction, poetry, or dialogue, and not an AI detector.
metadata:
  author: TABARC-Code
  author_url: https://github.com/TABARC-Code/
  version: 1.3.1
  dewey_decimal_code: "401.900"
  classification_label: "Psycholinguistics applied to written style and revision"
  layer: L4 Audit (with an L3 revise step)
  abstraction_level: Operational
---

# Syntax Friction Engine

Author: TABARC-Code

Models trained hard on maths, code and reasoning tend to write compressed prose. The words that help a human parse a sentence get dropped because a machine deriving an answer doesn't need them. This skill makes the text easier to read, counts the compressions it can see, and checks that nothing real was lost.

It rests on one preprint: Clark, Martin and Mahowald, arXiv:2610.29162 (21 October 2026, not peer reviewed). Two things the authors did not do, and you shouldn't pretend to: they didn't test real readers, and the features they counted don't identify who wrote a text. So this is a revision tool with a counter attached. Never use it to say a text was or wasn't written by an AI.

## What the counter is for, and what it isn't

A model cannot see its own density while writing, so a deterministic count gives the loop something to push against and gives you a before and after.

It is also easy to over-trust. In this skill's own first blind test (31 passages, judges who didn't know which version was which), text edited only until the scorer was satisfied rated 3.16 out of 5 for ease, exactly the same as the untouched originals. A plain revision that just shortened sentences and used ordinary words rated 4.74. An independent hand-count then found about five times more of the target constructions in the scorer-optimised text than the scorer did. Version 1.1 split long sentences but kept the author's paragraphs and wording, and rated 3.65. The plain revision's edge came from shorter sentences (about 12 words on average against 15), short paragraphs, dash-delimited lists unpacked into sentences, and ordinary words. Version 1.2 added the shorter-sentence, short-paragraph rewrite and reached 4.23 against the plain revision's 4.68: much better than 1.1, still behind on ease. Version 1.3's BLUNT intensity then reached 4.79 against 4.07 for the plain revision on 14 fresh passages, with 3.5 times fewer hand-counted constructions. Model judges, not real readers: a rating pack is in `reader-test/`. Lessons: sentence and paragraph shape matter as much as the six features, and the loop will happily learn to please its own counter. So readability comes first here, the counter second, and a hand-read last.

## The six features, plus one

| Feature | What it looks like | Usual fix | Scorer |
|---|---|---|---|
| Reduced object relative | "the papercut people feel" | put "that" back: "the papercut that people feel" | counted, medium; parser misses some |
| Late verb | subject, then twelve words, then the verb | move the verb up, hang the detail after it | counted, medium; parser dependent |
| Noun stack | "reader-patience budget", "database connection pool timeout" | two nouns at most, or unpack with "for" and "of" | counted, medium/high |
| Inanimate subject, animate verb | "this asymmetry bites", "the framework wants" | name who acts, or use a verb things really do | counted, lexicon based, candidates only |
| Denominal verb | "footnote it", "bottleneck the queue" | noun plus a plain verb: "add a footnote" | counted, lexicon based, low/medium |
| Low-frequency n-gram | odd word pairings no reader has met | rewrite in common words | optional: needs a reference table you build; low-confidence candidates only |
| Long sentence or paragraph (not from the paper) | a sentence over 25 words, a paragraph over 5 sentences | split at the natural join | counted separately, informational |

A clean score means "no countable hits". It does not mean "easy to read".

## Pick a mode

- **REPAIR**: the user gives you text. Default for most requests.
- **DRAFT**: the user wants new technical prose. Brief yourself first, write, then run REPAIR once.
- **AUDIT**: the user wants a report and no edits. Score, list the lines, stop.

## Intensity

- **BLUNT** (default for text a model wrote, or when the user says it sounds AI, or asks for "plain", "blunt" or "as simple as possible", or the readers are non-specialists): FULL with the dials turned up. See step 3. In the last blind test it read easiest (4.79 out of 5, against 4.00 for FULL and 4.07 for a plain prompt) and had the fewest hand-counted constructions. It also changes the most, so it asks the most of the keep list: two small complaints in 14 passages.
- **FULL** (text of unknown origin, or when the reader is a specialist who values the exact wording): rewrite for the reader at a gentler setting. There is no human voice in the text to protect, but nothing needs flattening.
- **LIGHT** (text the user wrote themselves and wants kept in their voice): fix only what the steps below flag, and leave every other sentence word for word.

If you can't tell who wrote it, use FULL and say so in the report. Text from reference documentation or a manual was handled well by BLUNT in testing, but check its terms of art first. All intensities keep the facts exactly.

Instruction files for models (SKILL.md and the like) are fair game for the prose, but headings, names, and trigger phrases are fixed. Stop and ask, or decline, when the text is fiction, verse, dialogue, a quotation, a contract clause, or anything where the dense or odd construction is the point. A reduced relative is normal in speech and nearly invisible in a novel. Leave code blocks alone; the scorer already skips them.

## Setup

The scorer lives in `scripts/` next to this file. It needs spaCy and an English model:

```
pip install spacy && python -m spacy download en_core_web_md
```

Optional, for the sixth feature: `python3 -I scripts/build_ngrams.py YOUR_DOCS_FOLDER -o counts.json`, then add `--ngram-counts counts.json` to `score`.

Use `python3 -I scripts/friction_score.py`. The `-I` stops a stray file in the current directory shadowing a module. If you can't install anything, say so, do the passes below by hand, and report it as "checked by eye, not counted". Never invent numbers.

After any change to the scorer or `references/lexicon.json`, run `python3 -I scripts/selftest.py`. The fixtures are the answer key. A scorer with no outside standard drifts.

## REPAIR procedure

1. **Score first.** `friction_score.py score FILE --lines`. Note words, friction per 100 words, flagged lines, average sentence length, and how many sentences and paragraphs run long.
2. **Decide whether to edit at all.** The text is clean only if all four hold: no medium or high confidence hits, no sentence over 25 words (22 under BLUNT), no paragraph over 5 sentences (five is acceptable; aim for about four), and the hand-read in step 5 finds no stumble. If the scorer and your own count of long sentences disagree, trust the higher count. Each list item counts as its own paragraph. Clean text stays word for word; editing it adds new tells, and the paper's own data says recent models are improving.
3. **Readability pass.** This is the part readers notice.
   - Before editing, write a keep list: every number, name, unit, date, quantity word ("many", "most", "some", "often"), hedge or modal ("may", "likely", "must", "should"), and every condition ("if", "unless", "when", "suppose"). After editing, tick each one off. A claim must come out exactly as strong as it went in: don't turn "may be" into "is", "is" into "may be", or a conditional into a flat statement.
   - Add nothing: no new counts or labels ("five of them matter"), no emphasis words ("especially", "crucially"), no new causes or predictions. Blind judges caught exactly these in earlier tests.
   - FULL: aim for an average of 12 to 15 words a sentence and none over 25, one idea per sentence. Keep paragraphs to about four sentences and one idea each; break a wall of text. Unpack dash-delimited lists, inline colon lists and nested asides into their own sentence ("This covers A, B and C."). Keep the subject next to its verb. Keep every "that". Choose the ordinary word over the coined or abstract one, and a verb over a noun made from it ("moves the cost of decoding", not "transfers the decoding cost"). Say who or what acts. You may reorder clauses and add small connectives; you may not add claims. Turning a bare "Platform wants" into "The platform team wants" is fine when the source already implies it; never add a person, number or reason the source doesn't give.
   - BLUNT: average 10 to 12 words a sentence, none over 22; paragraphs of three sentences at most; every list or aside becomes its own sentences; ordinary words everywhere, even where a term of art is shorter (spell it out once, then use it). Read it back against the keep list twice: this is the intensity most likely to flatten a condition.
   - LIGHT: split only sentences over about 25 words, leave the rest word for word, and keep the author's spelling and voice.
   - All intensities: keep headings, lists, code, links and UK English as they are. If a fix needs a fact you don't have, such as who actually acts, leave the line and say so. Don't invent an actor.
4. **Targeted pass for what is still flagged.** Use the fix table below, worst flag first, one construction per edit. Judge each flag before obeying it: low-confidence hits are candidates, "the report argues" is idiom, a noun stack that is a term of art ("database connection pool") stays once it has been spelled out. When you judge a flag false, log it: add a `reject` line to `references/feedback-ledger.md` if you can write there, otherwise name it in the report. A hit you judge false doesn't make the text dirty for steps 2 and 8.
5. **Hand-read.** Read every sentence once as a reader new to the topic would. The scorer is blind to some of what it is meant to catch: bare relatives the parser misfiles ("a timeout the client never saw resolved"), a subject cut off from its verb by a paired aside, figurative verbs outside the lexicon. If you stumble, fix it, even when the scorer is happy.
6. **Rescore and compare.** `friction_score.py compare BEFORE AFTER`. If the meaning guard fails (numbers lost, content recall under 0.55, length grown past 1.6 times), put the offending sentence back and try a smaller edit. Don't patch on top of a failed edit.
7. **Loop at most three rounds.** Stop when no medium or high hits remain and no long sentence or paragraph is left unjustified, or when a round removes nothing. Past that is churn, and chasing the count is how the loop went wrong in the first test.
8. **Report.** See the format below.

## DRAFT procedure

Write this brief to yourself before the first sentence. It's cheaper to avoid the habits than to repair them.

- Name the reader and what they already know. Write to that person.
- Aim for sentences averaging 12 to 15 words (10 to 12 under BLUNT), none over 25, one idea each, and paragraphs of about four sentences.
- Keep the subject close to its verb. If a sentence needs a long description of the subject, finish the verb first, then add the description.
- Use "that" in relative clauses. It costs one word.
- Let people or named systems act. Say what a thing does, not what it "wants" or "bites".
- At most two nouns in a row. Anything longer gets "for", "of" or "in".
- Use the plain verb. "Add a footnote", not "footnote it".

Then draft, then score it and hand-read it. If it is clean on all three tests of REPAIR step 2, say so and stop. If not, run REPAIR once. Don't iterate on your own draft more than that.

When the request leaves out a fact you need, such as a client's name or the real command, put a bracketed placeholder in the text and list it in the report. Don't invent it.

## Fix patterns

| Before | After | Why it works |
|---|---|---|
| Enterprises that evaluate models only on accuracy and latency are missing a readability axis. | If you judge models only on accuracy and latency, you miss a readability axis. | Condition moves into an "if" clause; the verb comes straight after a short subject. |
| The report the editor revised is ready. | The report that the editor revised is ready. | Marks the clause boundary; one word. |
| The migration of the legacy billing tables from the old cluster to the new region completed overnight. | The migration completed overnight. The legacy billing tables moved from the old cluster to the new region. | Verb arrives early; detail follows. |
| The database connection pool timeout setting is wrong. | The timeout setting for the database connection pool is wrong. | Relations are spelled out. |
| This asymmetry bites when the cache is cold. | This asymmetry causes slow requests when the cache is cold. | Says what actually happens. |
| We should bottleneck the queue. | We should make the queue the limiting step. | Noun plus plain verb. |
| A model trained mostly on human text, evaluated mostly on whether it sounds human, tends to write like a human. | A model trained mostly on human text tends to write like a human, especially when it is evaluated on whether it sounds human. | Long aside moves behind the verb. |

## Report format

Keep it short. Put the revised text first, then:

```
Friction per 100 words: 3.2 -> 0.4   (hits 8 -> 1, words 248 -> 262)
Sentences over 25 words: 4 -> 0   Paragraphs over 5 sentences: 2 -> 0
Intensity: BLUNT (model-written)
Keep list: 9 items, all present at the same strength
Guard: pass (numbers kept, content recall 0.91)
Hand-read: 2 stumbles found, both fixed
Left alone: two lines, and why
Judged false or idiom: 1 of the remaining hits (logged)
Scorer blind spots touching this text: ...
```

"Hits" counts every flagged line, low confidence included. Say how many survivors you judged false or idiom, so nobody mistakes judgement for failure. If the count didn't fall, say that. If the guard failed and you reverted a line, say which. When you work through several texts in one go, give each a short report, not one shared block.

## Feedback ledger (how this skill gets better)

`references/feedback-ledger.md` is the loop. After a run, add one line for anything the user accepted, rejected, or caught that the scorer missed.

- **Rejected fix or false flag** (negative feedback): note it. The second time the same verb or phrase is rejected, add it to `suppress` in `references/lexicon.json`.
- **Accepted fix** (positive feedback): note the pattern. Two acceptances of the same rewrite shape is a candidate for the fix table.
- **A miss the user spotted**: add a fixture to `tests/fixtures.json` first, as a known miss if you can't fix it yet, then fix the scorer or lexicon. Run `selftest.py`.
- **A regression**: if a version made things worse by any outside measure, say so in the ledger. Version 1.0's first blind test is logged there as the example.

Information runs both ways: the scorer constrains the revision, and what the revision keeps rejecting constrains the scorer. This skill is unfinished by design; the ledger is where that shows.

## Links

Only links that change behaviour are declared. Each has a matching note in the other skill (the exact text is in `links-for-other-skills.md`; some of those skills may not be installed where you work).

- **humanizer** (out): after the readability and feature passes, run it for lexical tells (banned words, rhetorical patterns). This skill doesn't look at vocabulary habits.
- **humanizer** (in): when it finds dense or clipped syntax rather than word-level tells, it hands the text here.
- **overwatch-prose-audit** (in): its audit routes syntax findings here and expects a before-and-after report back. (out): lexical findings go back to it or to humanizer.
- **technical-clarity-engine** (out, on request): when the user wants a restricted vocabulary, not just easier syntax. (in): it can hand over text whose vocabulary is already controlled but whose sentences are still long.
- **em-dash-calibration** (out): unpacking dash lists in FULL and BLUNT already lowers dash density; hand the result over for the final dash check.
- **professional-technical-writing** (in/out): document structure and layout live there; sentence shape lives here. Use it first for a whole manual, then this for the prose.

The links also carry evidence, not just instructions. What this skill learns (the fix table, the lexicon, the known misses) is worth sending to those skills; what they learn about false flags and accepted rewrites is worth bringing back into the ledger.

## Known limits (read before trusting a number)

- Counts are proxies for processing effort. They aren't comprehension scores, and no real reader was tested yet (the rating pack is the way to fix that).
- The parser is the weak point. It misfiles some bare relatives and loses the subject on very long sentences. The self-test lists five known misses.
- The animate-verb and denominal lists are small and editable. Expect misses and some false flags.
- The default thresholds (noun stack of three, subject-to-verb gap of seven words, long sentence of 25 words, long paragraph of 5 sentences) are heuristics, not values from the paper.
- Low-frequency n-grams are scored only if you build a reference table with `scripts/build_ngrams.py` from a corpus matched to your readers, and even then as low-confidence candidates beside the main count.
- A larger parser (`en_core_web_lg`, set with `SFE_MODEL`) was tried: it cleared two known misses and broke two passing fixtures, so the medium model stays the default.
- No human reference density ships with this. Use before/after, not an absolute pass mark.
- The scorer and the revision loop share a blind spot by construction. That is why the hand-read exists.
