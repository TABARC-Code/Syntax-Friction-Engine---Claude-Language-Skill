#!/usr/bin/env python3
"""
friction_score.py - count syntactic friction features in English prose.

Author: TABARC-Code

Five of the six features from Clark, Martin and Mahowald (arXiv:2610.29162, 2026)
are counted. The sixth, low-frequency n-grams, needs a reference corpus: build one with
build_ngrams.py and pass --ngram-counts. Without it the feature is reported as "unscored".
Even with it, hits are low confidence and are reported beside, not inside, the main count.

Two features (animate verbs on inanimate subjects, denominal verbs) are lexicon
based. The paper used a classifier. Treat those hits as candidates.

Usage:
  friction_score.py score FILE [FILE ...] [--lines] [--json] [--gate N] [--ngram-counts TABLE.json]
  friction_score.py compare BEFORE AFTER [--json]

Exit codes: 0 fine, 1 gate exceeded or meaning guard tripped, 2 setup problem.
"""
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

SCORER_VERSION = "1.7"
NGRAM_MIN_UNIGRAM = 20  # each word must appear this often in the reference for an unseen pair to count
LONG_PARAGRAPH = 5  # sentences; informational, like long sentences
LONG_SENTENCE = 25  # words; not one of the paper's six features, reported beside them
HERE = Path(__file__).resolve().parent
DEFAULT_LEXICON = HERE.parent / "references" / "lexicon.json"

FEATURES = [
    "reduced_object_relative",
    "late_verb",
    "noun_stack",
    "inanimate_subject_animate_verb",
    "denominal_verb",
]
UNSCORED = ["low_frequency_ngram"]

NE_SKIP = {"PERSON", "GPE", "ORG", "DATE", "TIME", "MONEY", "PERCENT", "CARDINAL",
           "ORDINAL", "NORP", "FAC", "LOC", "PRODUCT", "EVENT", "WORK_OF_ART", "LAW", "LANGUAGE"}
REL_TAGS = {"WDT", "WP", "WP$", "WRB"}
ADVERBIAL_HEADS = {"time", "moment", "day", "way", "reason", "place", "year", "week", "night",
                   "morning", "point", "instant", "hour", "month", "season", "occasion", "case"}
REL_WORDS = {"that", "which", "who", "whom", "whose", "where", "when", "why"}


def load_nlp():
    try:
        import spacy
    except ImportError:
        sys.stderr.write("spaCy is not installed. Run: pip install spacy && python -m spacy download en_core_web_md\n")
        sys.exit(2)
    import os
    forced = os.environ.get("SFE_MODEL")  # e.g. en_core_web_lg; untested models may break fixtures
    for name in ([forced] if forced else []) + ["en_core_web_md", "en_core_web_sm"]:
        try:
            return spacy.load(name)
        except OSError:
            if forced and name == forced:
                sys.stderr.write(f"SFE_MODEL={forced} could not be loaded; falling back to the default model.\n")
            continue
    sys.stderr.write("No English spaCy model found. Run: python -m spacy download en_core_web_md\n")
    sys.exit(2)


def load_lexicon(path):
    with open(path, encoding="utf-8") as fh:
        lex = json.load(fh)
    verbs = {}
    for cls, items in lex["animate_verbs"].items():
        for v in items:
            verbs[v] = cls
    lex["_verb_class"] = verbs
    lex["_animate_nouns"] = set(lex["animate_nouns"])
    lex["_denominal"] = set(lex["denominal_verbs"])
    lex["_denominal_low"] = set(lex["denominal_low_confidence"])
    sup = lex.get("suppress", {})
    lex["_sup_verbs"] = set(sup.get("verbs", []))
    lex["_sup_denom"] = set(sup.get("denominal", []))
    lex["_sup_phrases"] = [p.lower() for p in sup.get("phrases", [])]
    return lex


def clean_markdown(text):
    """Drop code, URLs, tables and markup so they do not pollute the counts."""
    text = re.sub(r"```.*?```", "\n", text, flags=re.S)
    text = re.sub(r"`[^`\n]*`", "IDENT", text)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"\b[a-z]+(?:-[a-z]+){2,}\b", "IDENT", text)  # kebab-case names such as skill or package names
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append("")
            continue
        if s.startswith("|") or re.fullmatch(r"[-=*_ ]{3,}", s):
            continue
        s = re.sub(r"^#{1,6}\s*", "", s)
        if re.match(r"^([-*+]|\d+[.)])\s+", s):
            out.append("")  # each list item is its own paragraph
        s = re.sub(r"^([-*+]|\d+[.)])\s+", "", s)
        s = re.sub(r"[*_]{1,3}([^*_\n]+)[*_]{1,3}", r"\1", s)
        if len(s.split()) <= 6 and not re.search(r"[.!?:;]$", s):
            out.append("")  # heading or label, not running prose
            continue
        out.append(s)
    return "\n".join(out)


def is_word(t):
    return not (t.is_punct or t.is_space or t.text == "IDENT")


PREFIXES = {"sub", "non", "pre", "post", "re", "anti", "co", "semi", "multi", "inter", "intra",
            "over", "under", "self", "cross", "meta", "micro", "macro", "mini", "mid", "vice",
            "ex", "pro", "un", "bi", "tri", "auto", "pseudo", "quasi", "ultra", "hyper"}


def nounish(t):
    if t.i + 1 < len(t.doc) and t.doc[t.i + 1].text == "-" and t.lower_ in PREFIXES:
        return False  # "sub-skill" is one word, not two nouns
    return (t.pos_ in ("NOUN", "PROPN") and t.text != "IDENT"
            and t.ent_type_ not in NE_SKIP)


def find_hits(sent, lex, ngram=None):
    hits = []
    sent_text = sent.text.strip()
    low = sent_text.lower()
    if any(p in low for p in lex["_sup_phrases"]):
        return hits, 0

    overt = 0

    # 1. object relatives with the relativiser dropped
    for t in sent:
        if t.dep_ != "relcl":
            continue
        before = [c for c in t.subtree if c.i <= t.i]
        has_rel = any(c.tag_ in REL_TAGS or c.lower_ in REL_WORDS for c in before)
        own_subj = [c for c in t.children if c.dep_ in ("nsubj", "nsubjpass") and c.i < t.i]
        if has_rel:
            overt += 1
            continue
        head = t.head
        if head.dep_ == "pobj" and head.head.pos_ == "ADP" and head.head.i == sent.start:
            continue  # fronted adverbial phrase then a new clause: "After six attempts the client gives up."
        if head.lemma_.lower() in ADVERBIAL_HEADS:
            continue  # "every time a word reaches", "the day I arrived": optional that, no object gap
        if any(x.text in (";", ":") for x in sent.doc[min(head.i, t.i):max(head.i, t.i) + 1]):
            continue  # a relative clause does not cross a semicolon or colon; parse artefact
        if own_subj:
            span = " ".join(x.text for x in t.head.subtree if x.i <= t.i and x.i >= t.head.left_edge.i)
            hits.append(("reduced_object_relative", span, "medium",
                         f"no 'that' before '{own_subj[0].text} {t.text}'", t.head.i))

    # 2. subject far from its verb
    gap_limit = lex["thresholds"]["late_verb_gap"]
    for t in sent:
        if t.dep_ in ("nsubj", "nsubjpass") and t.head.i > t.i and t.head.pos_ in ("VERB", "AUX"):
            between = sent[t.i - sent.start + 1: t.head.i - sent.start]
            if any(x.text in (":", ";") for x in between):
                continue  # a colon or semicolon opens a new clause; not one dependency
            if sum(1 for x in between if x.text in ("\u2014", "\u2013")) == 1:
                continue  # a single dash opens a new clause; a pair is an aside inside one clause
            gap = sum(1 for x in between if is_word(x))
            if gap >= gap_limit:
                hits.append(("late_verb", f"{t.text} ... {t.head.text}", "medium",
                             f"{gap} words between subject and verb", t.i))

    # 3. noun stacks
    stack_min = lex["thresholds"]["noun_stack_min"]
    toks = list(sent)
    i = 0
    while i < len(toks):
        if nounish(toks[i]):
            j, words = i, []
            while j < len(toks):
                if nounish(toks[j]):
                    words.append(toks[j])
                    j += 1
                elif (toks[j].text in ("-", "–") and j + 1 < len(toks)
                      and nounish(toks[j + 1]) and words):
                    j += 1
                else:
                    break
            n_noun = sum(1 for w in words if w.pos_ == "NOUN")
            if len(words) >= stack_min and n_noun >= 2:
                conf = "high" if len(words) >= stack_min + 1 else "medium"
                hits.append(("noun_stack", sent.doc[words[0].i:words[-1].i + 1].text, conf,
                             f"{len(words)} nouns in a row", words[0].i))
            i = max(j, i + 1)
        else:
            i += 1

    # 4. animate verb on an inanimate subject
    for t in sent:
        if t.dep_ == "nsubj" and t.head.pos_ == "VERB" and t.pos_ in ("NOUN", "PROPN"):
            verb = t.head.lemma_.lower()
            cls = lex["_verb_class"].get(verb)
            if not cls or verb in lex["_sup_verbs"]:
                continue
            if t.head.text[:1].isupper() and t.head.i != sent.start:
                continue  # capitalised mid-sentence: a name such as "Olmo Think", not a verb
            if t.ent_type_ == "PERSON" or t.lemma_.lower() in lex["_animate_nouns"]:
                continue
            # a compound head such as "team lead" is fine if any compound part is animate
            if any(c.lemma_.lower() in lex["_animate_nouns"] for c in t.children if c.dep_ == "compound"):
                continue
            conf = {"figurative": "high", "agentive": "medium", "idiom": "low"}[cls]
            hits.append(("inanimate_subject_animate_verb", f"{t.text} {t.head.text}", conf,
                         f"{cls} verb '{verb}' on a non-person subject", t.i))

    # 4b. the tagger sometimes calls a third-person verb a noun ("This asymmetry bites.").
    # Narrow rule: figurative-class verb, tagged noun, sentence root, with a noun to its left.
    for t in sent:
        if (t.pos_ == "NOUN" and t.dep_ == "ROOT" and t.text.lower().endswith("s")
                and lex["_verb_class"].get(t.lemma_.lower()) == "figurative"
                and t.lemma_.lower() not in lex["_sup_verbs"]):
            subj = [c for c in t.children if c.i < t.i and c.dep_ in ("compound", "nsubj")
                    and c.pos_ in ("NOUN", "PROPN")]
            if subj and subj[-1].lemma_.lower() not in lex["_animate_nouns"] and subj[-1].ent_type_ != "PERSON":
                hits.append(("inanimate_subject_animate_verb", f"{subj[-1].text} {t.text}", "medium",
                             f"figurative verb '{t.lemma_.lower()}' (tagged as noun) on a non-person subject", t.i))

    # 5. denominal verbs (lexicon only)
    for t in sent:
        if t.pos_ == "VERB" and t.dep_ not in ("amod",) and t.lemma_.lower() in lex["_denominal"]:
            lem = t.lemma_.lower()
            if lem in lex["_sup_denom"]:
                continue
            conf = "low" if lem in lex["_denominal_low"] else "medium"
            hits.append(("denominal_verb", t.text, conf, f"noun used as verb: '{lem}'", t.i))

    # 6. unseen word pairings (optional; needs a reference table from build_ngrams.py)
    ngram_hits = []
    if ngram:
        uni, bi = ngram["unigrams"], ngram["bigrams"]
        usable = lambda t: t.is_alpha and not t.is_stop and t.pos_ in ("NOUN", "ADJ", "VERB") and t.ent_type_ == ""
        toks = list(sent)
        for a, b in zip(toks, toks[1:]):
            if usable(a) and usable(b):
                ua, ub = uni.get(a.lower_, 0), uni.get(b.lower_, 0)
                if ua >= NGRAM_MIN_UNIGRAM and ub >= NGRAM_MIN_UNIGRAM and f"{a.lower_} {b.lower_}" not in bi:
                    ngram_hits.append(("low_frequency_ngram", f"{a.text} {b.text}", "low",
                                       "pair absent from the reference table though both words are common", a.i))
        ngram_hits = ngram_hits[:2]
    # words inside double quotes are being cited, not used ("the framework wants to...")
    qspans = [(m.start(), m.end()) for m in re.finditer(r'\u201c[^\u201d]*\u201d|"[^"]*"', sent.doc.text)]
    if qspans:
        hits = [h for h in hits
                if not any(a <= sent.doc[h[4]].idx < b for a, b in qspans)]
    return [h[:4] for h in hits], overt, [h[:4] for h in ngram_hits]


def analyse(text, nlp, lex, ngram=None):
    cleaned = clean_markdown(text)
    paras = [p for p in re.split(r"\n\s*\n", cleaned) if p.strip()]
    words = 0
    sentences = 0
    sent_lens = []
    para_sents = []
    all_hits = []
    ngram_all = []
    overt_total = 0
    for doc in nlp.pipe(paras):
        n_in_para = 0
        for sent in doc.sents:
            n = sum(1 for t in sent if is_word(t))
            if n == 0:
                continue
            sentences += 1
            n_in_para += 1
            words += n
            sent_lens.append(n)
            hits, overt, nghits = find_hits(sent, lex, ngram)
            ngram_all.extend(dict(feature=f, span=sp, confidence=c, note=n, sentence=sent.text.strip()) for f, sp, c, n in nghits)
            overt_total += overt
            for feat, span, conf, note in hits:
                all_hits.append({"feature": feat, "span": span, "confidence": conf,
                                 "note": note, "sentence": sent.text.strip()})
        para_sents.append(n_in_para)
    counts = Counter(h["feature"] for h in all_hits)
    conf_counts = Counter(h["feature"] for h in all_hits if h["confidence"] in ("medium", "high"))
    per100 = (lambda n: round(100.0 * n / words, 2) if words else 0.0)
    return {
        "scorer_version": SCORER_VERSION,
        "words": words,
        "sentences": sentences,
        "avg_sentence_words": round(sum(sent_lens) / len(sent_lens), 1) if sent_lens else 0,
        "max_sentence_words": max(sent_lens) if sent_lens else 0,
        "long_sentences": sum(1 for n in sent_lens if n > LONG_SENTENCE),
        "long_paragraphs": sum(1 for n in para_sents if n > LONG_PARAGRAPH),
        "long_paragraph_limit": LONG_PARAGRAPH,
        "long_sentence_limit": LONG_SENTENCE,
        "counts": {f: counts.get(f, 0) for f in FEATURES},
        "per100": {f: per100(counts.get(f, 0)) for f in FEATURES},
        "total_hits": sum(counts.values()),
        "friction_per100": per100(sum(counts.values())),
        "confident_hits": sum(conf_counts.values()),
        "confident_per100": per100(sum(conf_counts.values())),
        "overt_relatives": overt_total,
        "unscored": ({} if ngram else {u: "needs a reference n-gram corpus; not counted" for u in UNSCORED}),
        "ngram_candidates": len(ngram_all),
        "ngram_hits": ngram_all,
        "hits": all_hits,
    }


CONTENT_POS = {"NOUN", "PROPN", "VERB", "ADJ", "NUM"}


def fingerprint(text, nlp):
    cleaned = clean_markdown(text)
    lemmas, nums, ents = Counter(), set(), set()
    for doc in nlp.pipe([p for p in re.split(r"\n\s*\n", cleaned) if p.strip()]):
        for t in doc:
            if t.pos_ in CONTENT_POS and not t.is_stop and t.text != "IDENT":
                lemmas[t.lemma_.lower()] += 1
        for e in doc.ents:
            ents.add(e.text.lower())
    for m in re.findall(r"\d[\d,]*(?:\.\d+)?%?", cleaned):
        nums.add(m.replace(",", ""))
    return lemmas, nums, ents


def compare(before, after, nlp, lex):
    a, b = analyse(before, nlp, lex), analyse(after, nlp, lex)
    la, na, ea = fingerprint(before, nlp)
    lb, nb, eb = fingerprint(after, nlp)
    kept = sum(min(c, lb.get(k, 0)) for k, c in la.items())
    total = sum(la.values())
    recall = round(kept / total, 3) if total else 1.0
    ratio = round(a["friction_per100"] / b["friction_per100"], 2) if b["friction_per100"] else None
    return {
        "before": {k: a[k] for k in ("words", "friction_per100", "confident_per100", "avg_sentence_words")},
        "after": {k: b[k] for k in ("words", "friction_per100", "confident_per100", "avg_sentence_words")},
        "per_feature_before": a["counts"],
        "per_feature_after": b["counts"],
        "reduction_ratio": ratio if ratio is not None else ("all hits removed" if a["friction_per100"] else "n/a"),
        "word_ratio": round(b["words"] / a["words"], 2) if a["words"] else None,
        "content_recall": recall,
        "numbers_lost": sorted(na - nb),
        "entities_lost": sorted(e for e in ea if e not in clean_markdown(after).lower()),
        "guard": guard_verdict(recall, na - nb, (b["words"] / a["words"]) if a["words"] else 1.0),
    }


def guard_verdict(recall, numbers_lost, word_ratio):
    """Heuristic thresholds, not validated against human judgement. Tune with the ledger."""
    problems = []
    if numbers_lost:
        problems.append(f"numbers lost: {sorted(numbers_lost)}")
    if recall < 0.55:
        problems.append(f"content recall {recall} < 0.55 (content may have been cut)")
    if word_ratio > 1.6:
        problems.append(f"length grew x{word_ratio:.2f} (> 1.6, likely padding)")
    return {"passed": not problems, "problems": problems}


def print_score(name, r, show_lines):
    print(f"== {name}")
    print(f"words {r['words']}  sentences {r['sentences']}  avg sentence {r['avg_sentence_words']}  longest {r['max_sentence_words']}  over {r['long_sentence_limit']} words: {r['long_sentences']}  paragraphs over {r['long_paragraph_limit']} sentences: {r['long_paragraphs']}")
    print(f"friction per 100 words: {r['friction_per100']}   (medium/high confidence only: {r['confident_per100']})")
    for f in FEATURES:
        print(f"  {f:34s} {r['counts'][f]:3d}  ({r['per100'][f]}/100w)")
    if r["unscored"]:
        print(f"  {'low_frequency_ngram':34s} unscored")
    else:
        print(f"  {'low_frequency_ngram (low conf.)':34s} {r['ngram_candidates']:3d}  (candidates, not in the total)")
    print(f"  (overt 'that/which' relatives seen: {r['overt_relatives']})")
    if show_lines:
        for h in r["hits"] + r["ngram_hits"]:
            print(f"- [{h['feature']} | {h['confidence']}] {h['span']!r}  ({h['note']})")
            print(f"    {h['sentence'][:200]}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("score")
    s.add_argument("files", nargs="+")
    s.add_argument("--lines", action="store_true")
    s.add_argument("--json", action="store_true")
    s.add_argument("--gate", type=float, default=None, help="exit 1 if friction per 100 words exceeds this")
    s.add_argument("--lexicon", default=str(DEFAULT_LEXICON))
    s.add_argument("--ngram-counts", default=None, help="JSON table from build_ngrams.py; adds low-confidence n-gram candidates")
    c = sub.add_parser("compare")
    c.add_argument("before")
    c.add_argument("after")
    c.add_argument("--json", action="store_true")
    c.add_argument("--lexicon", default=str(DEFAULT_LEXICON))
    args = ap.parse_args()

    nlp = load_nlp()
    lex = load_lexicon(args.lexicon)
    rc = 0
    ngram = None
    if args.cmd == "score" and args.ngram_counts:
        ngram = json.loads(Path(args.ngram_counts).read_text(encoding="utf-8"))
    if args.cmd == "score":
        results = {}
        for f in args.files:
            text = sys.stdin.read() if f == "-" else Path(f).read_text(encoding="utf-8")
            r = analyse(text, nlp, lex, ngram)
            results[f] = r
            if args.gate is not None and r["friction_per100"] > args.gate:
                rc = 1
        if args.json:
            print(json.dumps(results, indent=2))
        else:
            for f, r in results.items():
                print_score(f, r, args.lines)
    else:
        r = compare(Path(args.before).read_text(encoding="utf-8"),
                    Path(args.after).read_text(encoding="utf-8"), nlp, lex)
        if args.json:
            print(json.dumps(r, indent=2))
        else:
            print(f"friction/100w  {r['before']['friction_per100']} -> {r['after']['friction_per100']}   ratio {r['reduction_ratio']}")
            print(f"words {r['before']['words']} -> {r['after']['words']}  (x{r['word_ratio']})   content recall {r['content_recall']}")
            print(f"avg sentence {r['before']['avg_sentence_words']} -> {r['after']['avg_sentence_words']}")
            print(f"numbers lost: {r['numbers_lost'] or 'none'}   entities lost: {r['entities_lost'] or 'none'}")
            print("meaning guard:", "PASS" if r["guard"]["passed"] else "FAIL " + "; ".join(r["guard"]["problems"]))
        if not r["guard"]["passed"]:
            rc = 1
    sys.exit(rc)


if __name__ == "__main__":
    main()
