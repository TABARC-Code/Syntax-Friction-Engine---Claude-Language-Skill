#!/usr/bin/env python3
"""
build_ngrams.py - build a reference word-pair table for the sixth feature (low-frequency n-grams).

Author: TABARC-Code

  build_ngrams.py CORPUS_PATH [CORPUS_PATH ...] -o counts.json

CORPUS_PATH can be files or folders of .txt, .md or .rst. Use text a careful human wrote for
the same kind of reader as the text you will score: your own docs, a project's manual, a
folder of release notes. A word pair that never appears in that corpus, between two words
that each appear often, is a candidate for "a pairing this reader hasn't met".

This is a proxy. The paper used a large general corpus. A small or off-topic corpus gives
false flags, so scores that use it are marked low confidence and are never mixed into the
main count unless you ask for them.
"""
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

WORD = re.compile(r"[A-Za-z][A-Za-z'-]*")
SPLIT = re.compile(r"[.!?;:\n]+")


def iter_files(paths):
    for p in paths:
        p = Path(p)
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.suffix.lower() in (".txt", ".md", ".rst") and f.is_file():
                    yield f
        elif p.is_file():
            yield p


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="+")
    ap.add_argument("-o", "--out", required=True)
    args = ap.parse_args()

    uni, bi, words = Counter(), Counter(), 0
    files = 0
    for f in iter_files(args.paths):
        files += 1
        text = re.sub(r"```.*?```", " ", f.read_text(encoding="utf-8", errors="ignore"), flags=re.S)
        for chunk in SPLIT.split(text):
            toks = [w.lower() for w in WORD.findall(chunk)]
            words += len(toks)
            uni.update(toks)
            bi.update(zip(toks, toks[1:]))
    if not words:
        sys.stderr.write("No text found. Nothing written.\n")
        sys.exit(2)
    data = {
        "files": files,
        "words": words,
        "unigrams": dict(uni),
        "bigrams": {f"{a} {b}": c for (a, b), c in bi.items()},
    }
    Path(args.out).write_text(json.dumps(data), encoding="utf-8")
    print(f"{files} files, {words} words, {len(uni)} unigrams, {len(bi)} bigrams -> {args.out}")
    if words < 200_000:
        print("Warning: under 200,000 words. Expect many false flags; treat the feature as a hint only.")


if __name__ == "__main__":
    main()
