#!/usr/bin/env python3
"""
selftest.py - run the scorer against tests/fixtures.json and report pass/fail.

Author: TABARC-Code

Why this exists: the scorer is the skill's answer key. A critic with no external
standard drifts, so the fixtures are the standard. Run this after any edit to
friction_score.py or references/lexicon.json. A failing fixture means the scorer
changed behaviour, not that the fixture is wrong, unless you can say why.
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import friction_score as fs  # noqa: E402


def main():
    nlp = fs.load_nlp()
    lex = fs.load_lexicon(fs.DEFAULT_LEXICON)
    cases = json.loads((HERE.parent / "tests" / "fixtures.json").read_text(encoding="utf-8"))["cases"]
    failed = 0
    for c in cases:
        r = fs.analyse(c["text"], nlp, lex)
        problems = []
        for feat, minimum in c.get("expect", {}).items():
            if r["counts"][feat] < minimum:
                problems.append(f"expected >= {minimum} {feat}, got {r['counts'][feat]}")
        for feat in c.get("forbid", []):
            if r["counts"][feat] > 0:
                problems.append(f"expected 0 {feat}, got {r['counts'][feat]}")
        known = c.get("known_miss")
        if known and problems:
            status, problems_to_show, counted = "KNOWN", [f"known miss: {known}"], False
        elif known and not problems:
            status, problems_to_show, counted = "NOW OK", ["known_miss no longer misses; remove the flag"], False
        else:
            status = "ok  " if not problems else "FAIL"
            problems_to_show, counted = problems, bool(problems)
        print(f"{status} {c['id']:22s} hits={ {k: v for k, v in r['counts'].items() if v} }")
        for p in problems_to_show:
            print(f"       {p}")
        failed += counted
    # optional n-gram path: a tiny hand-made reference table
    table = {"unigrams": {"cache": 50, "stores": 50, "processes": 50, "service": 50, "handles": 50},
             "bigrams": {"cache stores": 9, "service handles": 9}}
    r = fs.analyse("The cache processes data. The service handles data.", nlp, lex, table)
    ok = r["ngram_candidates"] == 1
    print(f"{'ok  ' if ok else 'FAIL'} ngram-candidate-path     candidates={r['ngram_candidates']}")
    failed += (not ok)
    scored = [c for c in cases if not c.get("known_miss")]
    print(f"\n{len(scored) - failed}/{len(scored)} scored fixtures pass; "
          f"{len(cases) - len(scored)} known misses listed, not hidden")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
