#!/usr/bin/env python3
"""
score_ratings.py - unblind exported reader ratings.

Author: TABARC-Code

  python3 organiser/score_ratings.py reader1.json [reader2.json ...] [--key key.json]

Keep this folder (organiser/) away from your readers: key.json says which version is which.
Pass one export per reader. Output: mean ease per version type, and head-to-head counts.
"""
import json, statistics as st, sys
from pathlib import Path

args = [a for a in sys.argv[1:] if not a.startswith("--")]
key = json.loads(Path(sys.argv[sys.argv.index("--key") + 1] if "--key" in sys.argv else Path(__file__).resolve().parent / "key.json").read_text())
files = [a for a in args if a.endswith(".json") and not a.endswith("key.json")]
arms = ["original", "plain", "skill12", "skill13b"]
ease = {a: [] for a in arms}
h2h = {}
for f in files:
    for pid, r in json.loads(Path(f).read_text())["ratings"].items():
        if len(r) != 4 or pid not in key:
            continue
        m = key[pid]["map"]
        sc = {m[l]: v for l, v in r.items()}
        for a, v in sc.items():
            ease[a].append(v)
        for x in arms:
            for y in arms:
                if x < y:
                    t = h2h.setdefault((x, y), [0, 0, 0])
                    t[0 if sc[x] > sc[y] else 2 if sc[x] < sc[y] else 1] += 1
print("pages scored:", len(ease["original"]), "from", len(files), "reader file(s)")
for a in arms:
    if ease[a]:
        print(f"  {a:9s} mean ease {st.mean(ease[a]):.2f}")
print("head to head (first beats second / tie / second beats first):")
for (x, y), t in sorted(h2h.items()):
    print(f"  {x} vs {y}: {t[0]}/{t[1]}/{t[2]}")
print("plain = plain-prompt revision; skill12 = FULL; skill13b = BLUNT. Small samples: report counts, not claims.")
