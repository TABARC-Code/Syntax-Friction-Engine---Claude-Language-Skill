Reading test pack (TABARC-Code)

What it is: 14 short passages, four shuffled versions each, for people to rate from 1
(hard work) to 5 (effortless). It exists because every ease score so far came from model
judges, not readers.

For the readers
  Send them index.html only. It runs offline in any browser, phone included. Six pages is
  plenty. They press "Export my ratings" and send back my-ratings.json.

For you (the organiser)
  Do not send the organiser/ folder to readers and do not open key.json until ratings are in.
  When you have one or more exports:
      python3 reader-test/organiser/score_ratings.py reader1.json reader2.json
  The output is mean ease per version type and head-to-head counts.

What to compare against (model judges, 14 passages): BLUNT 4.79, plain prompt 4.07,
FULL 4.00, original 2.29. If real readers disagree, trust the readers, and add a line
to references/feedback-ledger.md.

Legend in the output: plain = plain-prompt revision, skill12 = FULL, skill13b = BLUNT.
